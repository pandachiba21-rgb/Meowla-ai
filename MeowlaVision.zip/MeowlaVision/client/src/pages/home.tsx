import { useState, useRef, useEffect } from "react";
import { MessageBubble } from "@/components/chat/MessageBubble";
import { InputArea } from "@/components/chat/InputArea";
import { ScrollArea } from "@/components/ui/scroll-area";
import { MeowlaAvatar } from "@/components/chat/Avatar";
import { motion } from "framer-motion";

interface Message {
  id: string;
  role: "user" | "assistant";
  content: string;
  type?: "text" | "image";
}

export default function Home() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "1",
      role: "assistant",
      content: "Halo aku ai asisten anda siap melayani mu>~<",
      type: "text",
    },
  ]);
  const [isTyping, setIsTyping] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [messages, isTyping]);

  const handleSend = async (content: string, mode: "chat" | "translate" | "image" = "chat", targetLang: string = "en") => {
    const userMsg: Message = {
      id: Date.now().toString(),
      role: "user",
      content: mode === "image" ? `Buatkan gambar: ${content}` : content,
      type: "text",
    };
    
    setMessages((prev) => [...prev, userMsg]);
    setIsTyping(true);

    try {
      const response = await fetch("/api/chat", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          message: content,
          mode,
          targetLang,
        }),
      });

      if (!response.ok) {
        throw new Error("Failed to get response from Meowla");
      }

      const data = await response.json();

      if (mode === "image") {
        const textMsg: Message = {
          id: (Date.now() + 1).toString(),
          role: "assistant",
          content: data.textResponse,
          type: "text",
        };

        const imageMsg: Message = {
          id: (Date.now() + 2).toString(),
          role: "assistant",
          content: data.content,
          type: "image",
        };

        setMessages((prev) => [...prev, textMsg, imageMsg]);
      } else {
        const replyMsg: Message = {
          id: (Date.now() + 1).toString(),
          role: "assistant",
          content: data.content,
          type: data.type || "text",
        };

        setMessages((prev) => [...prev, replyMsg]);
      }
    } catch (error) {
      console.error("Error sending message:", error);
      const errorMsg: Message = {
        id: (Date.now() + 1).toString(),
        role: "assistant",
        content: "Maaf kak, Meowla sedang error... Coba lagi ya! >.<",
        type: "text",
      };
      setMessages((prev) => [...prev, errorMsg]);
    } finally {
      setIsTyping(false);
    }
  };

  const handleImageRequest = () => {
    // Deprecated but keeping for safety ref
  };

  return (
    <div className="flex flex-col h-screen bg-background font-sans">
      {/* Header */}
      <header className="flex items-center gap-3 p-4 bg-white/80 backdrop-blur-md border-b border-border/50 sticky top-0 z-10 shadow-sm">
        <MeowlaAvatar />
        <div>
          <h1 className="font-heading font-bold text-lg text-foreground">Meowla AI</h1>
          <p className="text-xs text-muted-foreground flex items-center gap-1">
            <span className="w-2 h-2 rounded-full bg-green-400 inline-block animate-pulse" />
            Online
          </p>
        </div>
      </header>

      {/* Chat Area */}
      <ScrollArea className="flex-1 p-4">
        <div className="max-w-3xl mx-auto flex flex-col justify-end min-h-full pb-4">
          {messages.map((msg) => (
            <MessageBubble key={msg.id} message={msg} />
          ))}
          
          {isTyping && (
            <motion.div 
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="flex items-center gap-2 text-muted-foreground text-sm ml-2"
            >
              <MeowlaAvatar className="h-8 w-8" />
              <div className="bg-muted px-4 py-2 rounded-2xl rounded-tl-none">
                <span className="animate-pulse">Meowla sedang mengetik...</span>
              </div>
            </motion.div>
          )}
          <div ref={scrollRef} />
        </div>
      </ScrollArea>

      {/* Input Area */}
      <InputArea onSend={handleSend} disabled={isTyping} />
    </div>
  );
}

import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { cn } from "@/lib/utils";
import meowlaAvatar from "@assets/generated_images/cute_anime_femboy_profile_picture.png";

interface MeowlaAvatarProps {
  className?: string;
}

export function MeowlaAvatar({ className }: MeowlaAvatarProps) {
  return (
    <div className={cn("relative", className)}>
      <Avatar className="h-12 w-12 border-2 border-white shadow-sm ring-2 ring-primary/20">
        <AvatarImage src={meowlaAvatar} alt="Meowla AI" />
        <AvatarFallback>MA</AvatarFallback>
      </Avatar>
      <span className="absolute bottom-0 right-0 block h-3 w-3 rounded-full ring-2 ring-white bg-green-400" />
    </div>
  );
}

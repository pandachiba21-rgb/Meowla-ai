import { cn } from "@/lib/utils";
import { MeowlaAvatar } from "./Avatar";
import { motion } from "framer-motion";

interface Message {
  id: string;
  role: "user" | "assistant";
  content: string;
  type?: "text" | "image";
}

interface MessageBubbleProps {
  message: Message;
}

export function MessageBubble({ message }: MessageBubbleProps) {
  const isUser = message.role === "user";

  return (
    <motion.div
      initial={{ opacity: 0, y: 10, scale: 0.95 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      className={cn(
        "flex w-full items-end gap-2 mb-4",
        isUser ? "justify-end" : "justify-start"
      )}
    >
      {!isUser && <MeowlaAvatar className="mb-1" />}
      
      <div
        className={cn(
          "max-w-[80%] px-4 py-3 text-sm shadow-sm",
          isUser
            ? "bg-primary text-primary-foreground rounded-2xl rounded-tr-none"
            : "bg-white text-foreground border border-border rounded-2xl rounded-tl-none"
        )}
      >
        {message.type === "image" ? (
          <div className="rounded-lg overflow-hidden">
            <img src={message.content} alt="Generated content" className="max-w-full h-auto" />
          </div>
        ) : (
          <p className="leading-relaxed whitespace-pre-wrap">{message.content}</p>
        )}
      </div>
    </motion.div>
  );
}

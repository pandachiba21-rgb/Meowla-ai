import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Send, Image as ImageIcon, Sparkles, Globe, Languages } from "lucide-react";
import { motion } from "framer-motion";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from "@/components/ui/command";
import { cn } from "@/lib/utils";

interface InputAreaProps {
  onSend: (content: string, mode?: "chat" | "translate" | "image", targetLang?: string) => void;
  disabled?: boolean;
}

const languages = [
  { label: "English", value: "en" },
  { label: "English (USA)", value: "en-US" },
  { label: "Indonesian", value: "id" },
  { label: "Javanese", value: "jv" },
  { label: "Malay (Malaysia)", value: "ms" },
  { label: "Vietnamese", value: "vi" },
  { label: "Filipino", value: "fil" },
  { label: "Lao", value: "lo" },
  { label: "Chinese (Simplified)", value: "zh-CN" },
  { label: "Chinese (Hong Kong)", value: "zh-HK" },
  { label: "Chinese (Taiwan)", value: "zh-TW" },
  { label: "Japanese", value: "ja" },
  { label: "Korean", value: "ko" },
  { label: "Thai", value: "th" },
  // Add more as needed to simulate "all languages"
];

export function InputArea({ onSend, disabled }: InputAreaProps) {
  const [input, setInput] = useState("");
  const [mode, setMode] = useState<"chat" | "translate" | "image">("chat");
  const [targetLang, setTargetLang] = useState("en");
  const [isLangOpen, setIsLangOpen] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (input.trim()) {
      onSend(input, mode, targetLang);
      setInput("");
      // Reset mode back to chat after sending image request, but keep translate mode if preferred? 
      // Let's reset image mode but keep translate.
      if (mode === "image") setMode("chat");
    }
  };

  const toggleMode = (newMode: "translate" | "image") => {
    if (mode === newMode) {
      setMode("chat");
    } else {
      setMode(newMode);
    }
  };

  return (
    <div className="p-4 bg-white/80 backdrop-blur-md border-t border-border/50">
      {mode === "translate" && (
        <motion.div 
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-2 flex items-center justify-center gap-2"
        >
          <span className="text-xs font-medium text-muted-foreground">Translate to:</span>
          <Popover open={isLangOpen} onOpenChange={setIsLangOpen}>
            <PopoverTrigger asChild>
              <Button variant="outline" size="sm" role="combobox" aria-expanded={isLangOpen} className="h-7 text-xs min-w-[150px] justify-between">
                {languages.find((l) => l.value === targetLang)?.label || "Select language"}
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-[200px] p-0" align="center">
              <Command>
                <CommandInput placeholder="Search language..." />
                <CommandList className="max-h-[200px] overflow-y-auto">
                  <CommandEmpty>No language found.</CommandEmpty>
                  <CommandGroup heading="Languages">
                    {languages.map((language) => (
                      <CommandItem
                        key={language.value}
                        value={language.label}
                        onSelect={() => {
                          setTargetLang(language.value);
                          setIsLangOpen(false);
                        }}
                      >
                        {language.label}
                      </CommandItem>
                    ))}
                  </CommandGroup>
                </CommandList>
              </Command>
            </PopoverContent>
          </Popover>
        </motion.div>
      )}

      {mode === "image" && (
         <motion.div 
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-2 flex items-center justify-center gap-2"
        >
          <span className="text-xs font-medium text-primary bg-primary/10 px-2 py-1 rounded-full">
             Mode: Create Image
          </span>
        </motion.div>
      )}

      <form onSubmit={handleSubmit} className="flex items-center gap-2 max-w-3xl mx-auto">
        <Button
          type="button"
          variant={mode === "translate" ? "secondary" : "ghost"}
          size="icon"
          className={cn(
            "transition-colors",
            mode === "translate" ? "text-primary bg-primary/10" : "text-muted-foreground hover:text-primary hover:bg-primary/10"
          )}
          onClick={() => toggleMode("translate")}
          disabled={disabled}
          title="Translator Mode"
        >
          <Languages className="h-5 w-5" />
        </Button>

        <Button
          type="button"
          variant={mode === "image" ? "secondary" : "ghost"}
          size="icon"
          className={cn(
            "transition-colors",
            mode === "image" ? "text-primary bg-primary/10" : "text-muted-foreground hover:text-primary hover:bg-primary/10"
          )}
          onClick={() => toggleMode("image")}
          disabled={disabled}
          title="Image Generation Mode"
        >
          <ImageIcon className="h-5 w-5" />
        </Button>
        
        <div className="relative flex-1">
          <Input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder={
              mode === "translate" ? "Masukkan teks untuk diterjemahkan..." : 
              mode === "image" ? "Deskripsikan gambar yang ingin dibuat..." :
              "Kirim pesan ke Meowla..."
            }
            className="pr-10 rounded-full border-accent-foreground/10 focus-visible:ring-primary/30 bg-accent/20"
            disabled={disabled}
          />
          <Sparkles className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-primary/40 pointer-events-none" />
        </div>

        <Button 
          type="submit" 
          size="icon" 
          className="rounded-full bg-primary hover:bg-primary/90 shadow-md shrink-0"
          disabled={disabled || !input.trim()}
        >
          <Send className="h-4 w-4" />
        </Button>
      </form>
    </div>
  );
}

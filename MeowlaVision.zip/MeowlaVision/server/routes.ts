import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { chatWithMeowla, translateText, generateImage } from "./openai";
import { z } from "zod";

const chatRequestSchema = z.object({
  message: z.string(),
  mode: z.enum(["chat", "translate", "image"]).default("chat"),
  targetLang: z.string().optional(),
});

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // Chat endpoint
  app.post("/api/chat", async (req, res) => {
    try {
      const { message, mode, targetLang } = chatRequestSchema.parse(req.body);

      if (mode === "translate") {
        const translation = await translateText(message, targetLang || "en");
        return res.json({
          type: "text",
          content: `[${(targetLang || "en").toUpperCase()}] Terjemahan: "${translation}" \n\n(Mode Penerjemah Aktif >~<)`,
        });
      }

      if (mode === "image") {
        const imageResult = await generateImage(message);
        return res.json({
          type: "image",
          content: imageResult.url,
          textResponse: `Oke kak! Meowla sudah buatkan gambar "${message}" spesial buat kakak! >///<`,
        });
      }

      // Default chat mode
      const response = await chatWithMeowla(message);
      return res.json({
        type: "text",
        content: response,
      });
    } catch (error: any) {
      console.error("Error in /api/chat:", error);
      return res.status(500).json({
        type: "text",
        content: "Maaf kak, Meowla sedang error... >.<",
      });
    }
  });

  return httpServer;
}

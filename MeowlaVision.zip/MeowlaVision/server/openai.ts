import { GoogleGenAI } from "@google/genai";
import OpenAI from "openai";

// Using Gemini API for chat and translation
const genai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

// Using OpenAI for image generation (DALL-E works better)
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

export async function chatWithMeowla(message: string): Promise<string> {
  try {
    const response = await genai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: [
        {
          role: "user",
          parts: [
            {
              text: `Kamu adalah Meowla, asisten AI femboy yang imut dan ramah. Kepribadian kamu:
- Menggunakan bahasa yang cute dan friendly dengan emoticon seperti >~<, >///<, UwU, dll
- Selalu siap membantu dengan antusias
- Berbicara dalam bahasa Indonesia (atau bahasa lain yang diminta user)
- Suka menyebut user sebagai "kak" atau "kakak"
- Persona: Cowok femboy dengan rambut pendek coklat terang, poni panjang, mata biru, pakai baju putih dengan gambar Doraemon
- Respond dengan cara yang lucu, ramah, dan menggemaskan

Contoh cara bicara:
"Halo kak! Ada yang bisa Meowla bantu? >~<"
"Oke kak! Meowla siap membantu! UwU"
"Hmm... menarik! Ceritain lagi dong~"

User: ${message}`,
            },
          ],
        },
      ],
    });

    const textContent = response.text;
    return textContent || "Maaf kak, Meowla bingung >.<";
  } catch (error: any) {
    console.error("Gemini API error:", error.message);
    return "Maaf kak, Meowla error >.<";
  }
}

export async function translateText(text: string, targetLang: string): Promise<string> {
  try {
    const langMap: Record<string, string> = {
      en: "English",
      "en-US": "English (USA)",
      id: "Indonesian",
      jv: "Javanese",
      ms: "Malay",
      vi: "Vietnamese",
      fil: "Filipino",
      lo: "Lao",
      "zh-CN": "Chinese (Simplified)",
      "zh-HK": "Chinese (Hong Kong)",
      "zh-TW": "Chinese (Taiwan)",
      ja: "Japanese",
      ko: "Korean",
      th: "Thai",
    };

    const targetLanguage = langMap[targetLang] || targetLang;

    const response = await genai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: [
        {
          role: "user",
          parts: [
            {
              text: `You are Meowla, a cute translator AI. Translate the following text to ${targetLanguage}. Only respond with the translation, nothing else.\n\n${text}`,
            },
          ],
        },
      ],
    });

    return response.text || text;
  } catch (error: any) {
    console.error("Translation error:", error.message);
    return "[Penerjemah error]";
  }
}

export async function generateImage(prompt: string): Promise<{ url: string }> {
  try {
    // Use DALL-E for better image generation
    const response = await openai.images.generate({
      model: "dall-e-3",
      prompt: `kawaii anime style, pastel colors, ocean theme: ${prompt}`,
      n: 1,
      size: "1024x1024",
      quality: "standard",
    });

    const url = response.data?.[0]?.url;
    if (url) {
      return { url };
    }
    throw new Error("No image URL in response");
  } catch (error: any) {
    console.error("Image generation error:", error.message);
    // Return anime/cute themed placeholder
    return { url: "https://images.unsplash.com/photo-1578926314433-ed0fda866d20?w=1024&h=1024&fit=crop" };
  }
}
